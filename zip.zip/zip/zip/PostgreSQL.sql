CREATE TABLE tickers (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    last NUMERIC NOT NULL,
    buy NUMERIC NOT NULL,
    sell NUMERIC NOT NULL,
    volume NUMERIC NOT NULL,
    base_unit VARCHAR(10) NOT NULL
);
 
-- Insert values into the tickers table for specified columns
INSERT INTO tickers (name, last, buy, sell, volume, base_unit)
VALUES
    ('BTC/INR', 5963905.0, 5963905.0, 5972999.0, 7.26865, 'btc'),
    ('XRP/INR', 45.8626, 46.0, 46.4299, 446076.8, 'xrp'),
    ('ETH/INR', 285000.0, 285000.0, 285000.1, 101.539, 'eth'),
    ('TRX/INR', 10.28, 10.28, 10.3, 1298064.0, 'trx'),
    ('EOS/INR', 103.0, 102.0, 103.0, 1194.58, 'eos'),
    ('ZIL/INR', 3.15, 3.07, 3.15, 460122.0, 'zil'),
    ('BAT/INR', 23.674, 23.13, 23.831, 26029.41, 'bat'),
    ('ZRX/INR', 46.45, 45.45, 46.34, 22327.25, 'zrx'),
    ('REQ/INR', 11.4835, 11.5766, 11.9975, 13787.0, 'req'),
    ('NULS/INR', 108.0, 0.0, 0.0, 0.0, 'nuls');

 