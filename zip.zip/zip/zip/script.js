// script.js
const tickersContainer = document.getElementById('tickers');

// Fetch data from the server
fetch('/tickers')
  .then(response => response.json())
  .then(data => {
    // Update the webpage with fetched data
    data.forEach(ticker => {
      const tickerElement = document.createElement('div');
      tickerElement.classList.add('ticker');
      tickerElement.innerHTML = `
        <p><strong>Name:</strong> ${ticker.name}</p>
        <p><strong>Last:</strong> ${ticker.last}</p>
        <p><strong>Buy:</strong> ${ticker.buy}</p>
        <p><strong>Sell:</strong> ${ticker.sell}</p>
        <p><strong>Volume:</strong> ${ticker.volume}</p>
        <p><strong>Base Unit:</strong> ${ticker.base_unit}</p>
      `;
      tickersContainer.appendChild(tickerElement);
    });
  })
  .catch(error => console.error('Error fetching data:', error));
