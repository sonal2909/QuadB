// server.js
const express = require('express');
const axios = require('axios');
const { Pool } = require('pg');

const app = express();
const port = 3000;

// PostgreSQL configuration
const pool = new Pool({
  user: 'your_username',
  host: 'localhost',
  database: 'your_database_name',
  password: 'your_password',
  port: 5432,
});

// Fetch data from the API and store it in the database
const fetchDataAndStore = async () => {
  try {
    const response = await axios.get('https://api.wazirx.com/api/v2/tickers');
    const tickers = response.data;
    const top10 = tickers.slice(0, 10); // Get top 10 results

    // Insert data into PostgreSQL database
    await pool.query('DELETE FROM tickers'); // Clear previous data
    await Promise.all(top10.map(async (ticker) => {
      const { name, last, buy, sell, volume, base_unit } = ticker;
      await pool.query('INSERT INTO tickers (name, last, buy, sell, volume, base_unit) VALUES ($1, $2, $3, $4, $5, $6)', [name, last, buy, sell, volume, base_unit]);
    }));
    console.log('Data fetched and stored successfully!');
  } catch (error) {
    console.error('Error fetching or storing data:', error);
  }
};

// Fetch and store data initially on server start
fetchDataAndStore();

// Route to get stored data from the database
app.get('/tickers', async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM tickers');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching data from database:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});